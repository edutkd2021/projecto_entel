fastavro.validation
===================

.. autofunction:: fastavro._validation_py.validate

.. autofunction:: fastavro._validation_py.validate_many
