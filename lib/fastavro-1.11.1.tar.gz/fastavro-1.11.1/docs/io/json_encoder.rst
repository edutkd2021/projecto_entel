fastavro.io.json_encoder
========================

.. autoclass:: fastavro.io.json_encoder.AvroJSONEncoder
